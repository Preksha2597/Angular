import { Component, OnInit } from '@angular/core';
import { CustomerService, Customer } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private service:CustomerService) { }



  cust:Customer;
  ngOnInit() {


this.cust=this.getCustomer();
alert(this.cust.cid+" "+this.cust.cname);
  }


  getCustomer():Customer{

return this.service.getCustomer();
  }
}
